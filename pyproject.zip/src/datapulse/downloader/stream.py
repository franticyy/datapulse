import os
import requests


def download_stream(url: str, destination_file: str, progress=None, task_id=None, skip_existing: bool = False, chunk_size: int = 1024 * 1024):
    headers = {}
    existing_size = 0

    if os.path.exists(destination_file):
        existing_size = os.path.getsize(destination_file)

    mode = "wb"
    if existing_size > 0:
        headers["Range"] = f"bytes={existing_size}-"
        mode = "ab"

    resp = requests.get(url, headers=headers, stream=True, timeout=30)
    
    # 404, 403 veya 500 alırsa hata fırlatıp diğer aynaya atlasın
    resp.raise_for_status()

    # 206 Partial Content: Kaldığı yerden devam ediyor
    # 200 OK: Sıfırdan indiriyor
    if resp.status_code == 206:
        content_len = int(resp.headers.get("content-length", 0))
        full_total = existing_size + content_len
    else:
        existing_size = 0
        mode = "wb"
        full_total = int(resp.headers.get("content-length", 0))

    if progress and task_id is not None:
        progress.update(task_id, total=full_total, completed=existing_size)

    with open(destination_file, mode) as f:
        for chunk in resp.iter_content(chunk_size=chunk_size):
            if chunk:
                f.write(chunk)
                if progress and task_id is not None:
                    progress.update(task_id, advance=len(chunk))

    return destination_file