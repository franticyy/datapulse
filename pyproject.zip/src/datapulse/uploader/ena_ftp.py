from ftplib import FTP, FTP_TLS
from pathlib import Path


def upload_ena_ftp(
    file_path: str,
    username: str,
    password: str,
    server: str = "webin.ebi.ac.uk",
    port: int = 21,
    progress=None,
    task_id=None,
    chunk_size: int = 65536,
) -> bool:
    path = Path(file_path)
    if not path.is_file():
        raise FileNotFoundError(f"Dosya bulunamadı: {file_path}")

    # Önce standart FTP ile dene (Windows soket çakışmalarını ve TLS 10038/10054 hatalarını önler)
    try:
        ftp = FTP()
        ftp.connect(host=server, port=port, timeout=60)
        ftp.login(user=username, passwd=password)
        ftp.set_pasv(True)

        def _callback(block):
            if progress and task_id is not None:
                progress.update(task_id, advance=len(block))

        with open(path, "rb") as f:
            cmd = f"STOR {path.name}"
            ftp.storbinary(cmd, f, blocksize=chunk_size, callback=_callback)

        try:
            ftp.quit()
        except Exception:
            ftp.close()

        return True

    except Exception:
        # Standart FTP reddedilirse saf FTP_TLS ile dene
        ftps = FTP_TLS()
        ftps.connect(host=server, port=port, timeout=60)
        ftps.auth()
        ftps.login(user=username, passwd=password)
        ftps.prot_p()
        ftps.set_pasv(True)

        def _callback_tls(block):
            if progress and task_id is not None:
                progress.update(task_id, advance=len(block))

        with open(path, "rb") as f:
            cmd = f"STOR {path.name}"
            ftps.storbinary(cmd, f, blocksize=chunk_size, callback=_callback_tls)

        try:
            ftps.quit()
        except Exception:
            ftps.close()

        return True