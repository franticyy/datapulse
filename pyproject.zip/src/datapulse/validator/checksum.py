import hashlib
import time


def calculate_hash(path: str, algorithm: str = "sha256") -> str:
    """Calculates cryptographic hash digest with a retry tolerance for file descriptor release."""
    max_retries = 5
    for attempt in range(max_retries):
        try:
            hasher = getattr(hashlib, algorithm)()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except PermissionError:
            if attempt == max_retries - 1:
                raise
            time.sleep(0.2)

    hasher = getattr(hashlib, algorithm)()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def verify_checksum(file_path: str, expected_hash: str, algorithm: str = "sha256") -> bool:
    """Compares calculated hash against an expected reference hash."""
    actual_hash = calculate_hash(file_path, algorithm=algorithm)
    return actual_hash.strip().lower() == expected_hash.strip().lower()

def get_remote_checksum(self, remote_file_path: str) -> str:
        """Nextcloud üzerindeki dosyanın hash değerini çeker."""
        target_url = f"{self.dav_files_url}{remote_file_path.lstrip('/')}"
        headers = {"Depth": "0"}
        body = """<?xml version="1.0" encoding="utf-8" ?>
        <d:propfind xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns">
          <d:prop>
            <oc:checksums/>
          </d:prop>
        </d:propfind>"""
        try:
            res = self.session.request("PROPFIND", target_url, headers=headers, data=body)
            if res.status_code in (200, 207):
                text = res.text
                for part in text.split():
                    if "SHA256:" in part:
                        return part.split("SHA256:")[1].split("<")[0].strip()
                    if "MD5:" in part:
                        return part.split("MD5:")[1].split("<")[0].strip()
        except Exception as e:
            print(f"Uzak hash alınamadı: {e}")
        return ""