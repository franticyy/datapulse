import logging
import os
import requests

logger = logging.getLogger(__name__)


def download_stream(
    url: str,
    destination_file: str,
    progress=None,
    task_id=None,
    skip_existing: bool = False,
    chunk_size: int = 1024 * 1024,
) -> str:
    """
    URL'den dosyayı akışlı indirir. Yarıda kalan indirmeleri Range header ile devam ettirir.

    Args:
        url: İndirilecek URL
        destination_file: Hedef dosya yolu
        progress: Rich Progress nesnesi (opsiyonel)
        task_id: Rich task ID (opsiyonel)
        skip_existing: True ise tam inmiş dosyayı atlasın
        chunk_size: Chunk boyutu (varsayılan 1 MB)

    Returns:
        destination_file yolu

    Raises:
        requests.HTTPError: 4xx/5xx hatalarında (mirror failover için)
        requests.Timeout: Bağlantı kurulamazsa
    """
    headers = {}
    existing_size = 0

    if os.path.exists(destination_file):
        existing_size = os.path.getsize(destination_file)

    mode = "wb"
    if existing_size > 0:
        headers["Range"] = f"bytes={existing_size}-"
        mode = "ab"

    # connect timeout: 30s, read timeout: None (büyük dosyalar için sınırsız)
    resp = requests.get(url, headers=headers, stream=True, timeout=(30, None))

    # 404, 403, 500 gibi hatalarda exception fırlat → caller mirror'a geçer
    resp.raise_for_status()

    if resp.status_code == 416:
        # Range Not Satisfiable → dosya zaten tam inmiş
        logger.debug("HTTP 416: %s zaten tam, atlanıyor.", os.path.basename(destination_file))
        return destination_file

    if resp.status_code == 206:
        content_len = int(resp.headers.get("content-length", 0))
        full_total = existing_size + content_len
    else:
        existing_size = 0
        mode = "wb"
        full_total = int(resp.headers.get("content-length", 0)) or None

    if progress and task_id is not None:
        progress.update(task_id, total=full_total, completed=existing_size)

    with open(destination_file, mode) as f:
        for chunk in resp.iter_content(chunk_size=chunk_size):
            if chunk:
                f.write(chunk)
                if progress and task_id is not None:
                    progress.update(task_id, advance=len(chunk))

    return destination_file